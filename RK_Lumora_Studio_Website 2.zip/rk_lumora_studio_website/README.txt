RK LUMORA STUDIO WEBSITE
========================

FILES
-----
index.html  - website content
styles.css  - design and mobile-responsive layout
script.js   - mobile navigation and current year
images/     - put your project photographs here

PREVIEW
-------
Open index.html in a browser to preview. Internet is needed for the optional Google Fonts; the website otherwise works offline.

ADD YOUR OWN PHOTOS
-------------------
The portfolio uses placeholder panels for now. To add a photo:
1. Copy your image into the images/ folder, for example painting-project.jpg.
2. Open index.html in a text editor.
3. Find the portfolio placeholder <div class="photo-placeholder"> block you want to replace.
4. Replace that whole placeholder div with:
   <img class="portfolio-photo" src="images/painting-project.jpg" alt="Painting conservation project">
5. Add this CSS rule to styles.css:
   .portfolio-photo { width:100%; height:240px; object-fit:cover; display:block; }
6. Update the title and project description below it. Use only photos you own or have permission to publish and factual project details.

CONTACT DETAILS
---------------
WhatsApp: 070 389 0997 (link uses Sri Lanka country code +94)
Email: rklumorastudio@gmail.com

FREE HOSTING WITH GITHUB PAGES
------------------------------
1. Create/sign in to GitHub: https://github.com
2. Create a new PUBLIC repository called rk-lumora-studio.
3. Upload index.html, styles.css, script.js, README.txt, and your images folder/files into the repository root.
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Choose branch "main" and folder "/ (root)", then Save.
7. Wait for deployment. Settings -> Pages will show your website URL, normally:
   https://YOUR-USERNAME.github.io/rk-lumora-studio/
8. Open the link on your phone and test the navigation, WhatsApp and email links.

ALTERNATIVE FREE HOSTING
------------------------
Netlify: https://www.netlify.com/ . Sign in and use its manual deploy option to upload the website folder/ZIP if available in your account.

NOTES
-----
This is a static portfolio site. The WhatsApp button opens a WhatsApp chat and the email link opens the visitor's email app. It does not include a server-backed inquiry form. GitHub Pages gives a free github.io address; a custom .com domain usually costs extra. Your website is not online until you complete the publishing steps.
